package com.dogymate.util;

/*
Created By JEFRI SINGH
ON 27/7/18
*/
public class Cons {
    public static String USER_NAME = "user_name";
    public static String PASSWORD = "password";
    public static String RECEIVER_ID = "receiver_id";
    public static String RECEIVER_NAME = "receiver_name";
    public static String SELF_PROFILE = "self_profile";
    public static String AGE = "age";
    public static String BREEDS = "breeds";
    public static String SPRAYEDS = "sprayeds";
    public static String SEX = "sex";
}
